import pandas as pd
import sqlite3

file_path = "world_population(in).csv"
df = pd.read_csv(file_path, encoding="mac_roman")

df = df.loc[:, ~df.columns.str.contains('^Unnamed')]

df.columns = [
    "Rank",
    "Country_Code",
    "Country_Territory",
    "Capital",
    "Continent",
    "Population_2022",
    "Population_2020",
    "Population_2015",
    "Population_2010",
    "Population_2000",
    "Population_1990",
    "Population_1980",
    "Population_1970",
    "Area_km2",  
    "Density_per_km2",  
    "Growth_Rate",
    "World_Population_Percentage"
]


conn = sqlite3.connect("world_population.db")

df.to_sql("world_population", conn, if_exists="append", index=False)

conn.commit()
conn.close()